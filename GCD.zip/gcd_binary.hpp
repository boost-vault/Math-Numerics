//  (C) Copyright Yuriy Koblents-Mishke 2006, 2007.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __gcd_binary_hpp__
#define __gcd_binary_hpp__

namespace Koblents {
    
    // binary implementation of Stein algorithm with shifts
    template <typename IntType>
    IntType gcdBinaryStein(IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.

      // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
            
        // end of borrowed lines        
 
        // Implementation of binary Stein algorithm
        // by Yuriy Koblents-Mishke    
    
        IntType const one(1);
    
        IntType mOdds(zero); // the greatest divisors of m, n that are powers of 2 
        IntType nOdds(zero); 
    
        IntType const mask(one);  // binary mask to check for % 2
        
        for( ; !(m & mask) ; m >>= 1, mOdds++ ); // m stripped of trailing zeros
        for( ; !(n & mask) ; n >>= 1, nOdds++ );
    
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {     
              for( m -= n, m >>= 1; !(m & mask) ; m >>= 1 ); // strips trailing zeros from m
          } else {
              for( n -= m, n >>= 1; !(n & mask) ; n >>= 1 );     
          }
        }
        
        return m << (std::min)( mOdds, nOdds ); 
        // accounts for 2s as divisors;
    }    
} // namespace
#endif
