//  (C) Copyright Yuriy Koblents-Mishke 2006, 2007.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <limits>
#include <algorithm>
#include <functional>
#include <string>
#include <iterator>
#include <vector>

#include <boost/random.hpp>
#include <boost/timer.hpp>

#include <boost/rational.hpp>
#include <boost/math/common_factor.hpp>


// #include "gcd_stein_stepanov.hpp"
// #include "gcd_stein_Wikipedia.hpp"
#include "gcd_stein.hpp"
#include "gcd_binary.hpp"
#include "gcd_bin_tables.hpp"


// the template fuctor class calculates a function of two variables
// that are stored in containers, and updates iterators to the variables
template < typename T >
class funR {
private: 
// stored data
  typename std::vector<T>::const_iterator indX, indY;
  T (*fun) ( T n, T m ); //pointer to function
public:
  funR( typename std::vector<T>::const_iterator iX, 
        typename std::vector<T>::const_iterator iY, 
        T f( T n, T m ) ) :
    indX( iX ), indY( iY ), fun( f ) 
  {}
    
  T operator () () { return fun( *indX++, *indY++ ); }
};

// "Empty" action to time the overheads of tests.
template < typename T >   
T testHarness( T n, T m )
{ return n; } // just makes a copy

// adapter from T x to const T & x for math::gcd
template < typename T >
T math_gcd( T m, T n )
{  return boost::math::gcd( m, n ); }


template <typename T >
void runTest( std::string testName, T (* test)(T,T), 
              const unsigned repeat,
              const std::vector<T> & x, const std::vector<T> & y, 
              const std::vector<T> & reference )
{
  std::cout << testName << ":";
  
  boost::timer timer;
  std::vector< T > results(reference.size());

  funR<T> functor( x.begin(), y.begin(), test );
  for( unsigned i = 0; i != repeat; i ++ )
    std::generate( results.begin(), results.end(), functor );
  std::cout << '\t' << ( results == reference ? "OK" : "Failed" ) 
            << ",\t" << std::fixed << std::setprecision(3) << timer.elapsed()
            << " seconds" << std::endl;

// diagnostics 
  
//    if( results != reference )
//    {
//      typename std::vector<T>::const_iterator rs( results.begin());
//
//      for( int indx = 0, count = 0; rs != results.end() && count < 10; ++rs, ++indx )
//      {
//        if( results[indx] != reference[indx] )
//        {  
//          std::cout << "x: " << int(x[indx])
//                    << ", y: " << int(y[indx])
//                    << ", rs: " << int(results[indx])
//                    << ", rf: " << int(reference[indx])
//                    << std::endl;
//          ++count;
//        }
//      }
//
//    }
}

template < typename testType, bool is_specialized, bool is_signed >
struct unsigned_test
{
  void operator() ( unsigned const loops, 
                    std::vector< testType > x, 
                    std::vector< testType > y,
                    std::vector< testType > gcd_standard)
  {}
};

//template < typename testType >
//struct unsigned_test<testType, true, false> 
//{
//  void operator() ( unsigned const loops, 
//                    std::vector< testType > x, 
//                    std::vector< testType > y,
//                    std::vector< testType > gcd_standard)
//  {
//    // http://en.wikipedia.org/wiki/Binary_GCD_algorithm, May 01, 2006
//    // the code is almost as fast as my implementation of the same algorithm
//    runTest( "Wikipedia implementation of Binary GCD algorithm", 
//             Wikipedia::gcd_2006_05_01<testType>, 
//             loops,  x, y, gcd_standard );
//    
//    // http://en.wikipedia.org/wiki/Binary_GCD_algorithm, November 04, 2006
//    runTest( "Wikipedia implementation of Binary GCD algorithm", 
//             Wikipedia::gcd_2006_11_04<testType>, 
//             loops,  x, y, gcd_standard );
//    
//    // http://en.wikipedia.org/wiki/Binary_GCD_algorithm, November 04, 2006
//    // optimized version of code
//    runTest( "Wikipedia implementation of Binary GCD algorithm", 
//             Wikipedia::gcd_2006_11_04_optim<testType>, 
//             loops,  x, y, gcd_standard );
//    
//    // Above code modified from binary to arithmetic, 
//    // mostly to check how well optimizing compilers optimize, 
//    // and to compare with my arithmetic implementation
//    runTest( "Arithmetic version of Wikipedia implementation of GCD algorithm", 
//             Wikipedia::gcdSteinArithm<testType>, 
//             loops,  x, y, gcd_standard );
//  }
//};

template < typename testType >
struct unsigned_test<testType, true, true > 
{
  void operator() ( unsigned const loops, 
                    std::vector< testType > x, 
                    std::vector< testType > y,
                    std::vector< testType > gcd_standard)
  {
  // http://en.wikipedia.org/wiki/Binary_GCD_algorithm, November 04, 2006
  // runTest( "Wikipedia implementation of Binary GCD algorithm, 2006_11_04", 
  //          Wikipedia::gcd_2006_11_04<testType>, 
  //          loops,  x, y, gcd_standard );
  
  // http://en.wikipedia.org/wiki/Binary_GCD_algorithm, November 04, 2006
  // optimized version of code
  // runTest( "Wikipedia implementation of Binary GCD algorithm, 2006_11_04 optimized", 
  //          Wikipedia::gcd_2006_11_04_optim<testType>, 
  //          loops,  x, y, gcd_standard );
  }
};

// due to a mistake in the Boost random generator or GCC 3.4 compiler
// class boost::variate_generator< testType > sometimes produces numbers 
// that are lower than minimum allowed for the distribution
// (it works fine, however, with MSVC++8 )   

// a work around the error
template <typename E, typename D>
class randomFix : public boost::variate_generator<E, D >
{
private:
  typename boost::variate_generator<E, D >::result_type abs_min;
public:
  explicit randomFix( E eng, D distr ) 
    : boost::variate_generator<E, D >( eng, distr )
  {
    abs_min = 
      (std::numeric_limits<typename boost::variate_generator<E, D >
                                                      ::result_type >::min)();        
  };
      
      
  typename boost::variate_generator<E, D >::result_type operator () () 
  {
    typename boost::variate_generator<E, D >::result_type tmp = 
      boost::variate_generator<E, D >::operator()();
    // while the generated value is too small   
    for( ;tmp == abs_min; ) 
      tmp = boost::variate_generator<E, D >::operator()(); // generate another
    return tmp;
  }
};

template < typename testType >
void long_test( const char * nameOfType )
{

  const unsigned total = 2500000; // let it be 10 millions numbers
  unsigned const loops = 20; // number of repetitions
 

  std::cout << "Tests " << "repeated " << loops << " times, " 
            << "for " << total << " pairs of "<< nameOfType << " numbers each"
            << " (sizeof = " << sizeof( testType ) << " bytes)"
            << std::endl;
  std::cout << std::endl << "initialization, wait..." << std::endl << std::endl;
  
  std::numeric_limits<testType> lm;
  // a minimal signed number have no positive counterpart, 
  // and many algorithms fail on it;
  // for example, for signed char the limits are [-128:127]
  // with -(-128) usually equal -128 in binary machine arithmetics !!!
  testType distMin = lm.is_specialized && lm.is_signed ? (lm.min)()+1 
                                                       : (lm.min)();
  testType distMax = (lm.max)();  
  boost::uniform_int< testType > distrib( distMin, distMax ); 

  // distribution that maps to the limits
  
  boost::mt19937 rng;                 // see pseudo-random number randoms
  
                                      // see random number distributions
  randomFix<boost::mt19937 &, boost::uniform_int< testType > >
           random(rng, distrib);             // glues randomness and mapping  

  // generating vectors of random numbers:
  std::vector< testType > x(total), y(total);
  std::generate( x.begin(), x.end(), random );         
  std::generate( y.begin(), y.end(), random );
  
  
  // fill a reference vector by GCD calculated using Euclidian algorithm
  std::vector< testType > gcd_standard( total );
  std::generate( gcd_standard.begin(), gcd_standard.end(), 
                 funR<testType >( x.begin(), y.begin(), boost::gcd<testType> ));
  
  
  // tests:
  runTest( "Timing of test harness overheads", testHarness<testType>, 
              loops,  x, y, x );
  
// Timing for Boost implementation of Euclide algorithm
// for older versions of Boost, up to version 1.34

//  runTest( "Boost (rational numbers) implementation of Euclidian algorithm", 
//           boost::gcd<testType>, 
//           loops,  x, y, gcd_standard );

//  runTest( "Boost (math) implementation of Euclidian algorithm", 
//           math_gcd<testType>, 
//           loops,  x, y, gcd_standard );

  runTest( "Boost (math) implementation of GCD", 
           math_gcd<testType>, 
           loops,  x, y, gcd_standard );

  runTest( "Stein GCD algorithm (arithmetic)", 
           Koblents::gcdArithmeticStein<testType>, 
           loops,  x, y, gcd_standard );
     
  runTest( "Binary GCD algorithm", 
           Koblents::gcdBinaryStein<testType>, 
           loops,  x, y, gcd_standard );
           
  runTest( "Table GCD algorithm, 2 bit mask, 4 byte table", 
           Koblents::gcdTableStein2<testType>, 
           loops,  x, y, gcd_standard );
    
  runTest( "Templatized Table GCD algorithm, 2 bits mask, 4 bytes table", 
           Koblents::gcdTableStein<testType, 2 >, 
           loops,  x, y, gcd_standard );
    
  runTest( "Table GCD algorithm, 3 bit mask, 8 byte table", 
           Koblents::gcdTableStein3<testType>, 
           loops,  x, y, gcd_standard );
    
  runTest( "Templatized Table GCD algorithm, 3 bits mask, 8 bytes table", 
           Koblents::gcdTableStein<testType, 3 >, 
           loops,  x, y, gcd_standard );
    
  runTest( "Table GCD algorithm, 4 bit mask, 16 byte table", 
           Koblents::gcdTableStein4<testType>, 
           loops,  x, y, gcd_standard );
    
  runTest( "Templatized Table GCD algorithm, 4 bits mask, 16 bytes table", 
           Koblents::gcdTableStein<testType, 4 >, 
           loops,  x, y, gcd_standard );
    
  runTest( "Table GCD algorithm, 5 bit mask, 32 byte table", 
           Koblents::gcdTableStein5<testType>, 
           loops,  x, y, gcd_standard );
    
  runTest( "Templatized Table GCD algorithm, 5 bits mask, 32 bytes table", 
           Koblents::gcdTableStein<testType, 5 >, 
           loops,  x, y, gcd_standard );
    
  runTest( "Table GCD algorithm, 6 bit mask, 64 byte table", 
           Koblents::gcdTableStein6<testType>, 
           loops,  x, y, gcd_standard );
   
  runTest( "Templatized Table GCD algorithm, 6 bits mask, 32 bytes table", 
           Koblents::gcdTableStein<testType, 6 >, 
           loops,  x, y, gcd_standard );
    
  runTest( "Table GCD algorithm, 7 bit mask, 128 byte table", 
           Koblents::gcdTableStein7<testType>, 
           loops,  x, y, gcd_standard );
    
  runTest( "Templatized Table GCD algorithm, 7 bits mask, 128 bytes table", 
           Koblents::gcdTableStein<testType, 7 >, 
           loops,  x, y, gcd_standard );
    
  runTest( "Table GCD algorithm, 8 bit mask, 256 byte table", 
           Koblents::gcdTableStein8<testType>, 
           loops,  x, y, gcd_standard );
               
  runTest( "Templatized Table GCD algorithm, 8 bits mask, 256 bytes table", 
           Koblents::gcdTableStein<testType, 8 >, 
           loops,  x, y, gcd_standard );
    
  // http://en.wikipedia.org/wiki/Binary_GCD_algorithm, May 01, 2006
  // the code is almost as fast as my implementation of the same algorithm
  // runTest( "Wikipedia implementation of Binary GCD algorithm, 2006_05_01", 
  //          Wikipedia::gcd_2006_05_01<testType>, 
  //          loops,  x, y, gcd_standard );
  
  // Above code modified from binary to arithmetic, 
  // mostly to check how well optimizing compilers optimize, 
  // and to compare with my arithmetic implementation
  // runTest( "Arithmetic version of Wikipedia implementation of GCD algorithm", 
  //          Wikipedia::gcdSteinArithm<testType>, 
  //          loops,  x, y, gcd_standard );

  // Alexander Stepanov Notes on Programming,  2/22/2006
  // http://www.stepanovpapers.com/notes.pdf
  // the deeply templatized code from lectures notes 
  // was optimized for better understanding, not for speed
  // runTest( "Alexander Stepanov's implementation of Binary GCD algorithm", 
  //          Stepanov::stein_gcd<testType>, 
  //          loops,  x, y, gcd_standard );
  
  
  unsigned_test<testType, 
                std::numeric_limits<testType>::is_specialized, 
                std::numeric_limits<testType>::is_signed > signed_tests;
  
  signed_tests( loops, x, y, gcd_standard);
  
  std::cout  << std::endl;
}

  
int main(int argc, char *argv[])
{
    
  std::cout << "Program: " << argv[0] << std::endl;
  
  long_test< unsigned char >( "unsigned char" ); 
  long_test< unsigned short >( "unsigned short" ); 
  long_test< unsigned int >( "unsigned int" ); 
  long_test< unsigned long >( "unsigned long" ); 
  long_test< unsigned long long >( "unsigned long long" ); 
  long_test< signed char >( "signed char" ); 
  long_test< short >( "short" ); 
  long_test< int >( "int" ); 
  long_test< long >( "long" ); 
  long_test< long long >( "long long" ); 
  
  system("PAUSE");
  return EXIT_SUCCESS;
}
