//  (C) Copyright Yuriy Koblents-Mishke 2006, 2007.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __gcd_stein_hpp__
#define __gcd_stein_hpp__

namespace Koblents {

    //  A sraightforward implementation of the Stein algorithm for gcd 
    // with artithmetic divisions by two, modulus 2, and multiplication by two.
    
    // signed / unsigned implemented as in boost::math::gcd
    template <typename IntType>
    IntType gcdArithmeticStein(IntType n, IntType m) 
    {
            
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.

        
        // Avoid repeated construction
        IntType const zero = static_cast<IntType>( 0 );
    
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
    
        // end of borrowed lines        
 
        // Implementation of arithmetical Stein algorithm
        // by Yuriy Koblents-Mishke    

        IntType const p1 = static_cast<IntType>(2); 
                                 // the smallest prime number
        IntType const one = static_cast<IntType>(1);

        IntType mOdds(one); // the greatest divisors of m, n  
        IntType nOdds(one); // that are powers of 2
        
        for( ; m % p1 == zero ; m /= p1, mOdds *= p1 ); // m, n stripped of 
        for( ; n % p1 == zero ; n /= p1, nOdds *= p1 ); // divisors == 2
    
        for( ; n != m ; ) { // n == m is gcd
             if( n < m ) { 
                 for( m -= n, m /= p1; m % p1 == zero ; m /= p1 ); 
             } else { // m < n
                 for( n -= m, n /= p1; n % p1 == zero ; n /= p1 );
             }         
        }          
             
        return mOdds == one || nOdds == one ? m : m * std::min( mOdds, nOdds ); 
    }
    
} // namespace
#endif
