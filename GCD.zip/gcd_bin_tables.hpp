//  (C) Copyright Yuriy Koblents-Mishke 2006, 2007.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __gcd_table_var_1_hpp__
#define __gcd_table_var_1_hpp__

namespace Koblents {

    // Optimized implementation of Stein algorithm
    // using tables to save on shifts
    template <typename IntType>
    IntType gcdTableStein8( IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.
 

        // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m; 

        // end of borrowed lines        
 
        // Optimized implementation of Stein algorithm
        // using tables by Yuriy Koblents-Mishke    
    
        const unsigned char  mask_size = 8;
        IntType const mask( (1<< mask_size) -1); // binary mask to check for % 2
        static const unsigned char table[] = { 
                                           8, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           6, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           7, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           6, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
    
        IntType k;
        
        
        IntType mOdds( zero );     
        for( ; k=m&mask, !k; m >>= mask_size, mOdds += mask_size );
        m >>= table[k];
        mOdds += table[k];
    
        IntType nOdds( zero );  
        for( ; k=n&mask, !k; n >>= mask_size, nOdds += mask_size );
        n >>= table[k];
        nOdds += table[k];
          //std::cout << "init:n=" << n << ",k=" << k << std::endl;
        
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {    // strip trailing zeros from m-n
            m -= n;
            for( ; k=m&mask, !k; m >>= mask_size );
            m >>= table[k];
          } else {
            n -= m;
            for( ; k=n&mask, !k; n >>= mask_size );
            n >>= table[k];
          }
        }
        
        return m << std::min( mOdds, nOdds ); 
        // accounts for 2s as divisors
    }
    
    template <typename IntType>
    IntType gcdTableStein7(IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.
 

        // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
      
        // end of borrowed lines        
 
        // Optimized implementation of Stein algorithm
        // using tables by Yuriy Koblents-Mishke    

        const unsigned char  mask_size = 7;
        IntType const mask( (1<< mask_size) -1);  // binary mask to check for % 2
        static const unsigned char table[] = { 
                                           7, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           6, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
    
        IntType k;
        
        
        IntType mOdds( zero );     
        for( ; k=m&mask, !k; m >>= mask_size, mOdds += mask_size );
        m >>= table[k];
        mOdds += table[k];
    
        IntType nOdds( zero );  
        for( ; k=n&mask, !k; n >>= mask_size, nOdds += mask_size );
        n >>= table[k];
        nOdds += table[k];
          //std::cout << "init:n=" << n << ",k=" << k << std::endl;
        
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {    // strip trailing zeros from m-n
            m -= n;
            for( ; k=m&mask, !k; m >>= mask_size );
            m >>= table[k];
          } else {
            n -= m;
            for( ; k=n&mask, !k; n >>= mask_size );
            n >>= table[k];
          }
        }
        
        return m << std::min( mOdds, nOdds ); 
        // accounts for 2s as divisors
    }
    
    template <typename IntType>
    IntType gcdTableStein6(IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.
 

        // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
        
        // end of borrowed lines        
 
        // Optimized implementation of Stein algorithm
        // using tables by Yuriy Koblents-Mishke    

        const unsigned char  mask_size = 6;
        IntType const mask( (1<< mask_size) -1);  // binary mask to check for % 2
        static const unsigned char table[] = { 
                                           6, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
    
        IntType k;
        
        
        IntType mOdds( zero );     
        for( ; k=m&mask, !k; m >>= mask_size, mOdds += mask_size );
        m >>= table[k];
        mOdds += table[k];
    
        IntType nOdds( zero );  
        for( ; k=n&mask, !k; n >>= mask_size, nOdds += mask_size );
        n >>= table[k];
        nOdds += table[k];
          //std::cout << "init:n=" << n << ",k=" << k << std::endl;
        
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {    // strip trailing zeros from m-n
            m -= n;
            for( ; k=m&mask, !k; m >>= mask_size );
            m >>= table[k];
          } else {
            n -= m;
            for( ; k=n&mask, !k; n >>= mask_size );
            n >>= table[k];
          }
        }
        
        return m << std::min( mOdds, nOdds ); 
        // accounts for 2s as divisors
    }
    
    template <typename IntType>
    IntType gcdTableStein5(IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.
 

        // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
        
        // end of borrowed lines        
 
        // Optimized implementation of Stein algorithm
        // using tables by Yuriy Koblents-Mishke    

        const unsigned char  mask_size = 5;
        IntType const mask( (1<< mask_size) -1);  // binary mask to check for % 2
        static const unsigned char table[] = { 
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
    
        IntType k;
        
        
        IntType mOdds( zero );     
        for( ; k=m&mask, !k; m >>= mask_size, mOdds += mask_size );
        m >>= table[k];
        mOdds += table[k];
    
        IntType nOdds( zero );  
        for( ; k=n&mask, !k; n >>= mask_size, nOdds += mask_size );
        n >>= table[k];
        nOdds += table[k];
          //std::cout << "init:n=" << n << ",k=" << k << std::endl;
        
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {    // strip trailing zeros from m-n
            m -= n;
            for( ; k=m&mask, !k; m >>= mask_size );
            m >>= table[k];
          } else {
            n -= m;
            for( ; k=n&mask, !k; n >>= mask_size );
            n >>= table[k];
          }
        }
        
        return m << std::min( mOdds, nOdds ); 
        // accounts for 2s as divisors
    }
    
    template <typename IntType>
    IntType gcdTableStein4(IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.
 

        // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
        
        // end of borrowed lines        
 
        // Optimized implementation of Stein algorithm
        // using tables by Yuriy Koblents-Mishke    

        const unsigned char  mask_size = 4;
        IntType const mask( (1<< mask_size) -1);  // binary mask to check for % 2
        static const unsigned char table[] = { 
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
    
        IntType k;
        
        
        IntType mOdds( zero );     
        for( ; k=m&mask, !k; m >>= mask_size, mOdds += mask_size );
        m >>= table[k];
        mOdds += table[k];
    
        IntType nOdds( zero );  
        for( ; k=n&mask, !k; n >>= mask_size, nOdds += mask_size );
        n >>= table[k];
        nOdds += table[k];
          //std::cout << "init:n=" << n << ",k=" << k << std::endl;
        
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {    // strip trailing zeros from m-n
            m -= n;
            for( ; k=m&mask, !k; m >>= mask_size );
            m >>= table[k];
          } else {
            n -= m;
            for( ; k=n&mask, !k; n >>= mask_size );
            n >>= table[k];
          }
        }
        
        return m << std::min( mOdds, nOdds ); 
        // accounts for 2s as divisors
    }

    template <typename IntType>
    IntType gcdTableStein3(IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.
 

        // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
        
        // end of borrowed lines        
 
        // Optimized implementation of Stein algorithm
        // using tables by Yuriy Koblents-Mishke    

        const unsigned char  mask_size = 3;
        IntType const mask( (1<< mask_size) -1);  // binary mask to check for % 2
        static const unsigned char table[] = { 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
    
        IntType k;
        
        
        IntType mOdds( zero );     
        for( ; k=m&mask, !k; m >>= mask_size, mOdds += mask_size );
        m >>= table[k];
        mOdds += table[k];
    
        IntType nOdds( zero );  
        for( ; k=n&mask, !k; n >>= mask_size, nOdds += mask_size );
        n >>= table[k];
        nOdds += table[k];
          //std::cout << "init:n=" << n << ",k=" << k << std::endl;
        
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {    // strip trailing zeros from m-n
            m -= n;
            for( ; k=m&mask, !k; m >>= mask_size );
            m >>= table[k];
          } else {
            n -= m;
            for( ; k=n&mask, !k; n >>= mask_size );
            n >>= table[k];
          }
        }
        
        return m << std::min( mOdds, nOdds ); 
        // accounts for 2s as divisors
    }

    template <typename IntType>
    IntType gcdTableStein2(IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.
 

        // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
        
        // end of borrowed lines        
 
        // Optimized implementation of Stein algorithm
        // using tables by Yuriy Koblents-Mishke    

        const unsigned char  mask_size = 2;
        IntType const mask( (1<< mask_size) -1);  // binary mask to check for % 2
        static const unsigned char table[] = { 
                                           2, 0, 1, 0 };   
    
        IntType k;
        
        
        IntType mOdds( zero );     
        for( ; k=m&mask, !k; m >>= mask_size, mOdds += mask_size );
        m >>= table[k];
        mOdds += table[k];
    
        IntType nOdds( zero );  
        for( ; k=n&mask, !k; n >>= mask_size, nOdds += mask_size );
        n >>= table[k];
        nOdds += table[k];
          //std::cout << "init:n=" << n << ",k=" << k << std::endl;
        
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {    // strip trailing zeros from m-n
            m -= n;
            for( ; k=m&mask, !k; m >>= mask_size );
            m >>= table[k];
          } else {
            n -= m;
            for( ; k=n&mask, !k; n >>= mask_size );
            n >>= table[k];
          }
        }
        
        return m << std::min( mOdds, nOdds ); 
        // accounts for 2s as divisors
    }
    
    template< const unsigned char mask_size >
    static const unsigned char * ShiftsTable();
    
    template<>
    static const unsigned char * ShiftsTable<8>()
    { 
        static const unsigned char table[] = { 
                                           8, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           6, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           7, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           6, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
        return table;
    }

    template<>
    static const unsigned char * ShiftsTable<7>()
    { 
        static const unsigned char table[] = { 
                                           7, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           6, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
        return table;
    }

    template<>
    static const unsigned char * ShiftsTable<6>()
    { 
        static const unsigned char table[] = { 
                                           6, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
        return table;
    }

    template<>
    static const unsigned char * ShiftsTable<5>()
    { 
        static const unsigned char table[] = { 
                                           5, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0,
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
        return table;
    }

    template<>
    static const unsigned char * ShiftsTable<4>()
    { 
        static const unsigned char table[] = { 
                                           4, 0, 1, 0, 2, 0, 1, 0, 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
        return table;
    }

    template<>
    static const unsigned char * ShiftsTable<3>()
    { 
        static const unsigned char table[] = { 
                                           3, 0, 1, 0, 2, 0, 1, 0 };   
        return table;
    }

    template<>
    static const unsigned char * ShiftsTable<2>()
    { 
        static const unsigned char table[] = {
                                           2, 0, 1, 0 };
        return table;
    }

    template <typename IntType, const unsigned char mask_size >
    IntType gcdTableStein(IntType n, IntType m)
    {
    // Several startup lines below are borrowed from
    // Boost Rational library (file rational.hpp) versions 1.34 and earlier

    //  (C) Copyright Paul Moore 1999. Permission to copy, use, modify, sell and
    //  distribute this software is granted provided this copyright notice appears
    //  in all copies. This software is provided "as is" without express or
    //  implied warranty, and with no claim as to its suitability for any purpose.
 

        // Avoid repeated construction
        IntType zero(0);
    
        // This is abs() - given the existence of broken compilers with Koenig
        // lookup issues and other problems, I code this explicitly. (Remember,
        // IntType may be a user-defined type).
        if (n < zero)
            n = -n;
        if (m < zero)
            m = -m;
        
        // check for zeros
        if( m == zero )
            return n;
        if( n == zero )
            return m;  
        
        // end of borrowed lines        
 
        // Optimized implementation of Stein algorithm
        // using tables by Yuriy Koblents-Mishke    

        IntType const mask( (1<< mask_size) -1); // binary mask to check for % 2
        static const unsigned char * table = ShiftsTable<mask_size>();
    
        IntType k;
        
        
        IntType mOdds( zero );     
        for( ; k=m&mask, !k; m >>= mask_size, mOdds += mask_size );
        m >>= table[k];
        mOdds += table[k];
    
        IntType nOdds( zero );  
        for( ; k=n&mask, !k; n >>= mask_size, nOdds += mask_size );
        n >>= table[k];
        nOdds += table[k];
          //std::cout << "init:n=" << n << ",k=" << k << std::endl;
        
        for( ; n != m ; ) { // n == m is gcd
          if( n < m ) {    // strip trailing zeros from m-n
            m -= n;
            for( ; k=m&mask, !k; m >>= mask_size );
            m >>= table[k];
          } else {
            n -= m;
            for( ; k=n&mask, !k; n >>= mask_size );
            n >>= table[k];
          }
        }
        
        return m << std::min( mOdds, nOdds ); 
        // accounts for 2s as divisors
    }

} // namespace
#endif
