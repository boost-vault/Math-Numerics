//  (C) Copyright Yuriy Koblents-Mishke 2006, 2007.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

The directory contains C++ codes for fast calculations of greatest common denominators of signed and unsigned integer numbers of types char, short, int, long, and, if available, long long. The codes can also be applied for similar user-defined types.

The codes are stored in the following files:

1. gcd_bin_tables.hpp - a series of optimized implementations of binary GCD algorithms using tables for trading memory for speed

2. gcd_binary.hpp - a reasonably fast standard implementation of binary GCD

3. gcd_stein.hpp - an arithmetical implementation of Stain GCD algorithm

Also included:

4. timing.cpp - a program that tests speed of the above implementations and the current implementation of GCD in Boost Math library. It can also test speed of several other implementations of GCD, provided the respective lines of codes will be uncommented and the required header files are supplied.

5. AMD3500New.txt - a log of a timing tests for MinGW/gcc 3.4 and MSVC 8.0 that was run on a PC with a 2.2 GHz AMD Athlon 64 3500 processor under 32-bit Windows XP Pro. 

6. IntelP31GHzNew.txt - a similar log for 1 GHz Intel Pentium III processor, under Windows 2000 Pro.

7. MacPPC_G4TimingNew.txt - a similar log for 800 MHz PowerPC G4 processor (a dual processors system) under Mac OS X 10.4.

8. AMD3500Old.txt - a similar log made on the same computer for somewhat older version of the codes. It compares them with an implementation of GCD in Boost version 1.34 and earlier that used Euclid algorithm. It also compares the speed with two implementations from Wikipedia and with an implementation by Alexander Stepanov.

9. IntelP31GHzOld.txt - a similar older log for 1 GHz Intel Pentium III processor, under Windows 2000 Pro (for comparison with Euclid algorithm).

10. IntelP42_8GHzOld.txt - a similar older log for 2.8 GHz Intel Pentium 4 processor (older version of P4) under Windows XP Pro (for comparison with Euclid algorithm).

11. IntelP43_2GHZOld.txt - a similar older log for 3.2 GHz Intel Pentium 4 processor (recent version of P4) under Windows XP Home (for comparison with Euclid algorithm).

12. MacPPC_G4Old.txt - a similar older log for 800 MHz PowerPC G4 processor (dual processor system) under Mac OS X 10.4 (for comparison with Euclid algorithm).

13. timingOld.xls - a spreadsheet analyzing the older logs. 

14. runtests.bat - a Windows batch file that helps to run tests

15. readme.txt - this document.



Discussion of codes.

It is assumed that you know the binary GCD algorithm. If not, its description can be found on Wikipedia: 

http://en.wikipedia.org/wiki/Binary_gcd 

in an online book by Alexander Stepanov:

http://www.stepanovpapers.com/notes.pdf 

in the second volume of The Art of Computer Programming by Donald Knuth, and in many other sources.

GCD algorithms are usually comparing to the Euclid GCD algorithm, known for 2,300 years or so. It is known that binary GCD requires 50% less bit operations than Euclid GCD. However, computer instructions usually manipulate by more than single bits: they are inherently parallel, operating with words that, for modern architectures, consist of 32 or 64 bits.

The advantage of binary GCD over Euclid BCD depends on implementation, compiler, processor architecture, and other variables like memory cache. A typical "textbook" implementation provides of binary GCD something like 15% to 30% gain in speed over Euclid GCD. According to Knuth, for his imaginary MIX computer the gains are about 15% (with tight assembly codes). In my tests for unsigned int numbers, the gains of implementation from Wikipedia (as of 2006-05-01) varied from small negative (minus 3.5%) to 25%, respectively for 2.8 GHz Intel Pentium 4 and for 1 GHz Intel Pentium III. The gains obtained my implementation of a "textbook" binary GCD were not much better, in the range of minus 0.5% to 60%.

A classical way to improve a speed of algorithms is to store results of repeating calculations in tables. As a rule, it is faster to fetch a stored value from the table than to recalculate it.

The innermost loops of "textbook" implementations of binary GCD algorithm analyze the last bit of numbers. If the bit is zero, the number is shift to the right by one bit. The loops do not use the inherent bit-parallelism of processors. Fortunately, the process stops after the first bit with a 50% probability, after the second with 25% probability, etc. Otherwise it would be much slower. Still, it can be made faster by analyzing more than one trailing bits in one operation.

The optimized implementation of binary GCD algorithm in the file gcd_bin_tables.hpp does exactly this. It is parameterized by the number of bits it analyzes in each iteration. For example, with tail of size 4, we are analyzing four bits in one iteration. The process will stop after the first iteration in 15/16 of cases for initial stripping, and in 7/8 of cases for stripping of zeros after subtracting (because in this case the last bit is always zero). The table occupies only 16 bytes.

For 8-bit tails (256 bytes table), the respective numbers will be 255/256 and 127/128. 

The tests demonstrated that for different processors, compilers, and operation systems the gains of optimized implementation of binary GCD with 256-bytes table over Euclid GCD is in the range of 82% to 163%, with a typical gain of around 100%. Most of the gains, in the range of 54% to 116%, are achievable with a 16-bytes table; the last numbers make the implementation of binary GCD algorithm worthwhile even for small embedded processors.
