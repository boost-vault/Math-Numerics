// arch-tag: c37e27e4-7260-43fd-924e-acd094f98e0e
/*
 * (C) Copyright Neal D. Becker (2004)
 * Permission to copy, use, modify, sell and distribute this software
 * is granted provided this copyright notice appears in all copies.
 * This software is provided "as is" without express or implied
 * warranty, and with no claim as to its suitability for any purpose.
*/

#ifndef complex_adapt_hpp
#define complex_adapt_hpp

#include <complex>

#include <boost/iterator/iterator_adaptor.hpp>
#include <iterator>

namespace boost {

  /*!
    Iterate over the real part of a complex sequence
    from a sequence z, returns real(z[i]), real(z[i+1])...
  */
  template<typename BaseIterator>
  class complex_real_adapt : public boost::iterator_adaptor<
    complex_real_adapt<BaseIterator>,
    BaseIterator,
    typename std::iterator_traits<BaseIterator>::value_type::value_type // scalar type
> {


    friend class iterator_core_access;

  public:

    typedef typename boost::iterator_adaptor<
    complex_real_adapt<BaseIterator>,
    BaseIterator,
    typename std::iterator_traits<BaseIterator>::value_type::value_type
    > super_t;

    typedef typename std::iterator_traits<BaseIterator>::value_type complex_type;
    typedef typename complex_type::value_type scalar_type;

    complex_real_adapt() {}

    explicit complex_real_adapt (BaseIterator _base) :
      super_t (_base) {}

    scalar_type & dereference() const {
      return real (const_cast<complex_type&>(*this->base_reference()));
    }
    
  };

  template<typename BaseIterator>
  complex_real_adapt<BaseIterator> make_complex_real_adapt(BaseIterator const& begin) {
    return complex_real_adapt<BaseIterator> (begin);
  }

    
  /*!
    Iterate over the imag part of a complex sequence
    from a sequence z, returns imag(z[i]), imag(z[i+1])...
  */
  template<typename BaseIterator>
  class complex_imag_adapt : public boost::iterator_adaptor<
    complex_imag_adapt<BaseIterator>,
    BaseIterator,
    typename std::iterator_traits<BaseIterator>::value_type::value_type // scalar type
> {


    friend class iterator_core_access;

  public:

    typedef typename boost::iterator_adaptor<
    complex_imag_adapt<BaseIterator>,
    BaseIterator,
    typename std::iterator_traits<BaseIterator>::value_type::value_type
    > super_t;

    typedef typename std::iterator_traits<BaseIterator>::value_type complex_type;
    typedef typename complex_type::value_type scalar_type;

    complex_imag_adapt() {}

    explicit complex_imag_adapt (BaseIterator _base) :
      super_t (_base) {}

    scalar_type & dereference() const {
      return imag (const_cast<complex_type&>(*this->base_reference()));
    }
    
  };

  template<typename BaseIterator>
  complex_imag_adapt<BaseIterator> make_complex_imag_adapt(BaseIterator const& begin) {
    return complex_imag_adapt<BaseIterator> (begin);
  }

    

} // namespace boost

#endif

