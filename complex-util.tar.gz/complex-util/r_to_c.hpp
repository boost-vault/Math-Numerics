// arch-tag: 3a58794a-5c73-49dc-b011-b9665f6fcc94
/*
 * (C) Copyright Neal D. Becker (2004)
 * Permission to copy, use, modify, sell and distribute this software
 * is granted provided this copyright notice appears in all copies.
 * This software is provided "as is" without express or implied
 * warranty, and with no claim as to its suitability for any purpose.
*/

#ifndef r_to_c_hpp
#define r_to_c_hpp

#include <complex>

#include <boost/iterator/iterator_adaptor.hpp>
#include <iterator>

namespace boost {

  /*!
    View 2 iterators of 2 scalar sequences as a complex sequence,
    from 2 sequence s1,s2, returns complex (s1[i],s2[i]), complex (s1[i+1],s2[i+1])...
  */
  template<typename BaseIterator>
  class r_pair_to_c_adapt : public boost::iterator_adaptor<
    r_pair_to_c_adapt<BaseIterator>,
    BaseIterator,
    typename std::complex<typename std::iterator_traits<BaseIterator>::value_type>, // scalar type
    use_default,
    typename std::complex<typename std::iterator_traits<BaseIterator>::value_type>	// deref returns value, not ref
> {


    friend class iterator_core_access;

  public:

    typedef typename boost::iterator_adaptor<
    r_pair_to_c_adapt<BaseIterator>,
    BaseIterator,
    typename std::complex<typename std::iterator_traits<BaseIterator>::value_type>,
    use_default,
    typename std::complex<typename std::iterator_traits<BaseIterator>::value_type>
    > super_t;

    typedef typename std::iterator_traits<BaseIterator>::value_type scalar_type;
    typedef typename std::complex<scalar_type> complex_type;
    typedef typename std::iterator_traits<BaseIterator>::difference_type difference_type;

    r_pair_to_c_adapt() {}

    explicit r_pair_to_c_adapt (BaseIterator const& _base1, BaseIterator const& _base2) :
      base1 (_base1), base2 (_base2) {}

    complex_type dereference() const {
      return complex_type (*base1, *base2);
    }
    
    void increment() {
      ++base1;
      ++base2;
    }


    void decrement() {
      --base1;
      --base2;
    }


    void advance(difference_type n) {
      base1 += n;
      base2 += n;
    }

    difference_type
    distance_to(r_pair_to_c_adapt<BaseIterator> const& y) const { 
      return (y.base1 - base1);
    }

    bool equal (r_pair_to_c_adapt<BaseIterator> const& y) const {
      return distance_to (y) == 0;
    }

    BaseIterator base1;
    BaseIterator base2;
  };

  template<typename BaseIterator>
  r_pair_to_c_adapt<BaseIterator> make_r_pair_to_c_adapt(BaseIterator const& begin1, BaseIterator const& begin2) {
    return r_pair_to_c_adapt<BaseIterator> (begin1, begin2);
  }

  /*!
    View an iterator of a scalar sequence as a complex sequence,
    from a sequence s, returns complex (s[i],s[i+1]), complex (s[i+2],s[i+3])...
  */
  template<typename BaseIterator>
  class r_to_c_adapt : public boost::iterator_adaptor<
    r_to_c_adapt<BaseIterator>,
    BaseIterator,
    typename std::complex<typename std::iterator_traits<BaseIterator>::value_type>, // scalar type
    use_default,
    typename std::complex<typename std::iterator_traits<BaseIterator>::value_type>	// deref returns value, not ref
> {


    friend class iterator_core_access;

  public:

    typedef typename boost::iterator_adaptor<
    r_to_c_adapt<BaseIterator>,
    BaseIterator,
    typename std::complex<typename std::iterator_traits<BaseIterator>::value_type>,
    use_default,
    typename std::complex<typename std::iterator_traits<BaseIterator>::value_type>
    > super_t;

    typedef typename std::iterator_traits<BaseIterator>::value_type scalar_type;
    typedef typename std::complex<scalar_type> complex_type;
    typedef typename std::iterator_traits<BaseIterator>::difference_type difference_type;

    r_to_c_adapt() {}

    explicit r_to_c_adapt (BaseIterator const& _base) :
      super_t (_base) {}

    complex_type dereference() const {
      return complex_type (*this->base_reference(), *(this->base_reference()+1));
    }
    
    void increment() {
      this->base_reference() += 2;
    }


    void decrement() {
      this->base_reference() -= 2;
    }


    void advance(difference_type n) {
      this->base_reference() += 2*n;
    }

    difference_type
    distance_to(r_to_c_adapt<BaseIterator> const& y) const { 
      return (y.base_reference() - this->base_reference())/2;
    }

    bool equal (r_to_c_adapt<BaseIterator> const& y) const {
      return distance_to (y) == 0;
    }

    complex_type operator[] (difference_type n) {
      return complex_type (*(this->base_reference()+2*n), *(this->base_reference()+2*n+1));
    }

  };

  template<typename BaseIterator>
  r_to_c_adapt<BaseIterator> make_r_to_c_adapt(BaseIterator const& begin) {
    return r_to_c_adapt<BaseIterator> (begin);
  }

    

} // namespace boost

#endif

