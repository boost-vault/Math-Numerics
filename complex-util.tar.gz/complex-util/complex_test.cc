#include <boost/cstdlib.hpp>             // for boost::exit_success
#include "c_to_r.hpp"
#include "r_to_c.hpp"
#include "complex_adapt.hpp"
#include <boost/test/test_tools.hpp>     // for main, BOOST_CHECK

#include <iostream>  // for std::cout (std::endl indirectly)
#include <iterator>
#include <algorithm>
#include <vector>

int test_main (int, char**) {
  using namespace std;

  typedef std::complex<double> Complex;

  vector<Complex> x (4);
  vector<double> y (8);
  vector<double> x_r (4), x_i (4);

  for (int i = 0; i < x.size(); ++i) {
    x[i] = Complex (2*i, 2*i+1);
    y[2*i] = 2*i, y[2*i+1] = 2*i+1;
    x_r[i] = real (x[i]);
    x_i[i] = imag (x[i]);
  }


  vector<double> z (8);
  copy (boost::make_c_to_r_adapt (x.begin()), boost::make_c_to_r_adapt (x.end()), z.begin());
  BOOST_CHECK (y == z);

  vector<Complex> x2 (4);
  copy (boost::make_r_to_c_adapt (z.begin()), boost::make_r_to_c_adapt (z.end()), x2.begin());
  BOOST_CHECK (x == x2);

  vector<double> a (4);
  copy (boost::make_complex_real_adapt (x.begin()), boost::make_complex_real_adapt (x.end()), a.begin());
  BOOST_CHECK (a == x_r);

  vector<double> b (4);
  copy (boost::make_complex_imag_adapt (x.begin()), boost::make_complex_imag_adapt (x.end()), b.begin());
  BOOST_CHECK (b == x_i);

  vector<Complex> c (4);
  copy (boost::make_r_pair_to_c_adapt (x_r.begin(), x_i.begin()), boost::make_r_pair_to_c_adapt (x_r.end(), x_i.end()), c.begin());
  BOOST_CHECK (c == x);
}

  
