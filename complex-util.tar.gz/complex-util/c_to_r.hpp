#ifndef c_to_r_hpp
#define c_to_r_hpp

#include <complex>

#include <boost/iterator/iterator_adaptor.hpp>
#include <iterator>

namespace boost {

  /*!
    View an iterator of a complex sequence as a scalar sequence,
    from a sequence z, returns real(z[i]), imag(z[i]), real (z[i+1]) ...
  */
  template<typename BaseIterator>
  class c_to_r_adapt : public boost::iterator_adaptor<
    c_to_r_adapt<BaseIterator>,
    BaseIterator,
    typename std::iterator_traits<BaseIterator>::value_type::value_type
      
> {


    friend class iterator_core_access;

  public:

    typedef typename boost::iterator_adaptor<
    c_to_r_adapt<BaseIterator>,
    BaseIterator,
    typename std::iterator_traits<BaseIterator>::value_type::value_type
    > super_t;

    typedef typename std::iterator_traits<BaseIterator>::value_type complex_type;
    typedef typename complex_type::value_type scalar_type;
    typedef typename std::iterator_traits<BaseIterator>::difference_type difference_type;

    c_to_r_adapt() {}

    explicit c_to_r_adapt (BaseIterator _base) :
      super_t (_base), cnt (0) {}

    scalar_type & dereference() const {
      return (cnt % 2 == 0) ? real (const_cast<complex_type&>(*this->base_reference())) : imag (const_cast<complex_type&>(*this->base_reference()));
    }

//     scalar_type & dereference() {
//       return (cnt % 2 == 0) ? real (*this->base_reference()) : imag (*this->base_reference());
//     }
    
    void increment() {
      cnt++;
      if (cnt == 2) {
	++this->base_reference();
	cnt = 0;
      }
    }


    void decrement() {
      cnt--;
      if (cnt < 0) {
	--this->base_reference();
	cnt = 1;
      }
    }


    void advance(difference_type n) {
      this->base_reference() += n/2;
      cnt += n % 2;
      if (cnt == 2) {
	++this->base_reference();
	cnt = 0;
      }
    }

    difference_type
    distance_to(c_to_r_adapt<BaseIterator> const& y) const { 
      return 2 * (y.base_reference() - this->base_reference()) + (y.cnt - cnt);
    }

    int cnt;
  };

  template<typename BaseIterator>
  c_to_r_adapt<BaseIterator> make_c_to_r_adapt(BaseIterator const& begin) {
    return c_to_r_adapt<BaseIterator> (begin);
  }
    

} // namespace boost

#endif

